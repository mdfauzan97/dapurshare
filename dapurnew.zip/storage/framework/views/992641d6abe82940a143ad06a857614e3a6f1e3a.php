<?php $__env->startSection('content'); ?>
<div class="mx-auto sm:px=4 mt-32">
    <div class="flex flex-wrap justify-center">
        <div class="md:w-2/3 pr-4 pl-4">
            
                <div class="relative py-3 sm:max-w-xl mx-auto text-center">
                    <span class="text-2xl font-light">Login to your account</span>
                    <div class="relative mt-4 bg-white shadow-md sm:rounded-lg text-left">
                    <div class="h-2 bg-indigo-400 rounded-t-md"></div>
                    <div class="py-6 px-8">
                        
                        <form action="<?php echo e(route('login')); ?>" method="POST">
                          <?php echo csrf_field(); ?>    
                                <div>
                                  <label class="block font-semibold"><?php echo e(__('E-Mail Address')); ?><label>
                                  <input id="email" type="text" placeholder="Email" class=" border w-full h-5 px-3 py-5 mt-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-indigo-600 rounded-md <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="hidden mt-1 text-sm text-red" role="alert">
                                              <strong><?php echo e($message); ?><strong>
                                          </span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                              
                                <div>
                                  <label class="block mt-3 font-semibold"><?php echo e(__('Password')); ?><label>
                                  <input id="password" type="password" placeholder="Password" class=" border w-full h-5 px-3 py-5 mt-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-indigo-600 rounded-md <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="hidden mt-1 text-sm text-red" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                                </div>  
                                
                                <div class="flex justify-between items-baseline">
                                  <button type="submit" class="mt-4 bg-indigo-500 text-white py-2 px-6 rounded-lg"><?php echo e(__('Login')); ?></button>
                                  <?php if(Route::has('password.request')): ?>
                                      <a href="<?php echo e(route('password.request')); ?>" class="text-sm hover:underline">Forgot password?</a>
                                  <?php endif; ?>
                                </div>
                        </form>
                          
                      </div>
                    </div>
                  
                  </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\dapurnew\resources\views/auth/login.blade.php ENDPATH**/ ?>